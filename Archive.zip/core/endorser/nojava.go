//+build !experimental

/*
Copyright IBM Corp. 2016 All Rights Reserved.

SPDX-License-Identifier: Apache-2.0
*/

package endorser

func javaEnabled() bool {
	return false
}
